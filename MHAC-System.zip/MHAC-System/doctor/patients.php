<?php 
    session_start();

    $timeout_duration = 1800;

    if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
        header("Location: ../login-signup.php");
        exit();
    }

    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout_duration) {
        session_unset();
        session_destroy();
        header("Location: ../login-signup.php?message=Session expired. Please log in again.");
        exit();
    }

    $_SESSION['last_activity'] = time();

    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Doctor') {
        header("Location: ../access_denied.php");
        exit();
    }

    include '../includes/db_connect.php';

    // Query to select only students who are registered as users and have an active status
    $query = "
        SELECT s.student_id, s.reg_number, s.email, s.name, s.program_of_study, 
            s.year_of_admission, s.expected_graduation_year, s.status, 
            s.date_of_birth, s.gender, s.phone_number 
        FROM Students s
        JOIN Users u ON s.student_id = u.student_id
        WHERE s.status = 'Active'
    ";

    $result = $conn->query($query);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Students - MUST Clinic Online</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* Responsive Table Wrapper */
        .table-container {
            width: 100%;
            max-height: 400px;
            overflow-x: auto;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-top: 20px;
            background-color: #f9f9f9;
        }

        .student-table {
            width: 100%;
            min-width: 900px;
            border-collapse: collapse;
            font-size: 0.9rem;
            text-align: left;
            table-layout: fixed;
        }

        .student-table th, .student-table td {
            padding: 12px;
            border: 1px solid #ddd;
            white-space: nowrap;
        }

        .student-table th {
            background-color: #007bff;
            color: white;
            position: sticky;
            top: 0;
            z-index: 2;
        }

        .student-table tbody tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .btn-check-record {
            padding: 5px 10px;
            font-size: 0.85rem;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .btn-check-record:hover {
            background-color: #218838;
        }

        .filter-container {
            margin-top: 20px;
            margin-bottom: 10px;
        }
        
        .filter-container label {
            margin-right: 10px;
        }

        .filter-container {
            display: flex;
            align-items: center;
            margin-top: 20px;
            margin-bottom: 10px;
        }

        #search-input {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 250px;
            margin-right: 20px;
            transition: border-color 0.3s;
        }

        #search-input:focus {
            border-color: #007bff; /* Change border color on focus */
            outline: none; /* Remove outline */
        }

        .gender-filter {
            display: flex;
            align-items: center;
        }

        .gender-label {
            margin-right: 15px;
            cursor: pointer;
            font-size: 0.9rem;
        }

        .gender-label input[type="radio"] {
            display: none; /* Hide default radio buttons */
        }

        .gender-label span {
            position: relative;
            padding-left: 25px; /* Space for custom radio */
        }

        .gender-label span:before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 16px;
            height: 16px;
            border: 2px solid #007bff; /* Border color */
            border-radius: 50%; /* Circle */
            background: white; /* Background color */
        }

        .gender-label input[type="radio"]:checked + span:before {
            background: #007bff; /* Background color when checked */
        }

        .gender-label input[type="radio"]:checked + span:after {
            content: '';
            position: absolute;
            left: 4px; /* Position for inner dot */
            top: 50%;
            transform: translateY(-50%);
            width: 8px; /* Inner dot size */
            height: 8px; /* Inner dot size */
            border-radius: 50%; /* Circle */
            background: white; /* Inner dot color */
        }

        
    </style>
</head>
<body>
    <div class="dashboard-container">
        <nav class="sidebar" id="sidebar">
            <button class="sidebar-toggle" id="sidebar-toggle" aria-label="Toggle Sidebar">
                <i class="fas fa-bars"></i>
            </button>
            <ul class="nav-list" aria-label="Sidebar Navigation">
            <li><a href="doctor_dashboard.php" aria-label="Dashboard"><i class="fas fa-tachometer-alt"></i><span class="nav-text">Dashboard</span></a></li>
                <li><a href="patients.php" aria-label="Manage Patients"><i class="fas fa-user-injured"></i><span class="nav-text">Patients</span></a></li>
                <li><a href="healthtips.php" aria-label="Health Tips"><i class="fas fa-heartbeat"></i><span class="nav-text">Health Tips</span></a></li>
                <li><a href="reports.php" aria-label="Reports"><i class="fas fa-chart-bar"></i><span class="nav-text">Reports</span></a></li>
                <li><a href="settings.php" aria-label="Settings"><i class="fas fa-cogs"></i><span class="nav-text">Settings</span></a></li>
                <li><a href="../includes/logout.php" aria-label="Logout"><i class="fas fa-sign-out-alt"></i> <span class="nav-text">Logout</span></a></li>
            </ul>
        </nav>

        <div class="main-content">
            <header class="header">
                <h1>Manage Patients</h1>
            </header>

            <div class="filter-container">
            <input type="text" id="search-input" placeholder="Search by name" onkeyup="filterStudents()">
                
                <label><input type="radio" name="gender" value="All" onclick="filterByGender('All')" checked> All</label>
                <label><input type="radio" name="gender" value="Male" onclick="filterByGender('Male')"> Male</label>
                <label><input type="radio" name="gender" value="Female" onclick="filterByGender('Female')"> Female</label>
            </div>
            <div id="not-found-message" style="display: none; color: red; margin-top: 20px;">
                No matching records found.
            </div>

            <div class="table-container">
                <table class="student-table" id="student-table">
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Registration Number</th>
                            <th>Name</th>
                            <th>Program of Study</th>
                            <th>Gender</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['student_id']; ?></td>
                                <td><?php echo $row['reg_number']; ?></td>
                                <td><?php echo $row['name']; ?></td>
                                <td><?php echo $row['program_of_study']; ?></td>
                                <td><?php echo $row['gender']; ?></td>
                                <td>
                                    <form action="check_medical_record.php" method="get">
                                        <input type="hidden" name="student_id" value="<?php echo $row['student_id']; ?>">
                                        <button type="submit" class="btn-check-record">Check Medical Record</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        function filterStudents() {
            let searchInput = document.getElementById('search-input').value.toLowerCase();
            let gender = document.querySelector('input[name="gender"]:checked').value;
            let table = document.getElementById('student-table');
            let rows = table.getElementsByTagName('tr');
            let found = false; // Flag to track if any row is displayed

            for (let i = 1; i < rows.length; i++) {
                let nameCell = rows[i].getElementsByTagName('td')[2];
                let genderCell = rows[i].getElementsByTagName('td')[4];

                if (nameCell && genderCell) {
                    let name = nameCell.textContent.toLowerCase();
                    let rowGender = genderCell.textContent.trim();

                    // Check if the row matches the name and gender filters
                    let nameMatches = name.includes(searchInput);
                    let genderMatches = (gender === 'All' || rowGender === gender);

                    // Show or hide the row based on both filters
                    if (nameMatches && genderMatches) {
                        rows[i].style.display = '';
                        found = true; // At least one row is found
                    } else {
                        rows[i].style.display = 'none';
                    }
                }
            }

            // Show "Not Found" statement if no rows are found
            let notFoundMessage = document.getElementById('not-found-message');
            if (!found) {
                notFoundMessage.style.display = 'block'; // Show the message
            } else {
                notFoundMessage.style.display = 'none'; // Hide the message
            }
        }

        // Update the input events to call the combined function
        document.getElementById('search-input').addEventListener('keyup', filterStudents);
        const genderRadios = document.querySelectorAll('input[name="gender"]');
        genderRadios.forEach(radio => {
            radio.addEventListener('change', filterStudents);
        });
    </script>


</body>
</html>
