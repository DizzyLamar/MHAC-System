<?php
// includes/db_connection.php

$host = 'localhost:3306';
$db   = 'mhac_db';
$user = 'root';
$password = '';

// Establish the connection using MySQLi and assign it to $conn
$conn = new mysqli($host, $user, $password, $db);

// Check if the connection was successful
if ($conn->connect_error) {
    error_log('Database Connection Error: ' . $conn->connect_error);
    echo '<script>alert("Database connection failed");</script>';
    exit('Database connection failed.');
} else {
    echo '<script>console.log("Database connection successful");</script>';
}
?>
